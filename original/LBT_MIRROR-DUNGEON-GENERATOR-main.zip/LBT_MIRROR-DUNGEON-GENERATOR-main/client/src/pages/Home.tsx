/* Orbital Route Atlas: left-to-right route cartography using the user-authorized reference encounter icon set, rendered inside a compact hex waypoint frame. */
/* Dense cartographic editor: the selected waypoint and its current kind must remain legible, local, and actionable. */
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ChevronDown, ChevronRight, Crosshair, Download, ExternalLink, FileDown, FileUp, Maximize2,
  Minus, Move, Plus, Redo2, RotateCcw, Save, Trash2, Undo2, WandSparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";

type NodeKind = "origin" | "skirmish" | "focused" | "elite" | "anomaly" | "event" | "supply" | "rest" | "guardian" | "custom";
type Accent = "gold" | "ember" | "ash";
type RouteNode = { id: string; stage: number; kind: NodeKind; icon: string; label: string; accent: Accent };
type RouteTree = {
  title: string;
  nodes: RouteNode[];
  edges: [string, string][];
  theme: { background: string; line: string; showLabels: boolean; iconSize: number };
};

const STORAGE_KEY = "orbital-route-atlas.v2";
const MAX_COLUMNS = 10;
const MAX_NODES_PER_COLUMN = 3;
const HISTORY_LIMIT = 80;
const STANDARD_THEME = { background: "#07171b", line: "#70d9df" };
const LEGACY_STANDARD_THEME = { background: "#101720", line: "#6e8594" };
const DANTE_STANDARD_THEME = { background: "#16090c", line: "#9c3142" };
const asset = {
  logo: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663619237894/jQBlTeNNhwPADzZB.png",
  hero: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663619237894/LqcizDXlrLgPbSFx.jpg",
  texture: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663619237894/LEtUsohKDWEAJNky.jpg",
  reference: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663619237894/LEyqoVYchbPRYqTj.jpg",
};

const devIconSources = {
  origin: "/manus-storage/Dungeon_Entrance_Icon_3c3c7f17.png",
  skirmish: "/manus-storage/Normal_Encounter_Icon_ac411f79.png",
  focused: "/manus-storage/Monster_Encounter_Icon_2a9cacfe.png",
  elite: "/manus-storage/Coin_Encounter_Icon_86e6f39b.png",
  anomaly: "/manus-storage/Blubbering_Toad_Core_Icon_4b00b351.png",
  event: "/manus-storage/Event_Encounter_Icon_57c7965b.png",
  supply: "/manus-storage/Shop_Encounter_Icon_bbd20be7.png",
  rest: "/manus-storage/Rest_Stop_Encounter_Icon_c8e1da99.png",
  guardian: "/manus-storage/Boss_Encounter_Icon_2663c108.png",
} as const;

const bundledIconNames = {
  origin: "Dungeon_Entrance_Icon",
  skirmish: "Normal_Encounter_Icon",
  focused: "Monster_Encounter_Icon",
  elite: "Coin_Encounter_Icon",
  anomaly: "Blubbering_Toad_Core_Icon",
  event: "Event_Encounter_Icon",
  supply: "Shop_Encounter_Icon",
  rest: "Rest_Stop_Encounter_Icon",
  guardian: "Boss_Encounter_Icon",
} as const;

const viteEnv = (import.meta as ImportMeta & { env?: { BASE_URL?: string } }).env;
const appBase = viteEnv?.BASE_URL ?? "/";
const bundledIconBase = `${appBase}icons/`;
const usesBundledIcons = appBase !== "/";
export const encounterIconSources: Record<Exclude<NodeKind, "custom">, string> = usesBundledIcons
  ? Object.fromEntries(Object.entries(bundledIconNames).map(([kind, name]) => [kind, `${bundledIconBase}${name}.png`])) as Record<Exclude<NodeKind, "custom">, string>
  : devIconSources;

const kinds: Record<NodeKind, { label: string; short: string; description: string }> = {
  origin: { label: "開始", short: "始", description: "経路の出発地点" },
  skirmish: { label: "通常戦闘", short: "戦", description: "通常の敵と交戦する地点" },
  focused: { label: "強敵", short: "強", description: "強力な敵と集中して交戦する地点" },
  elite: { label: "危険戦闘", short: "危", description: "危険度が高い連続戦闘の地点" },
  anomaly: { label: "変則遭遇", short: "変", description: "通常と異なる特殊な遭遇地点" },
  event: { label: "イベント", short: "？", description: "内容が未確定、または選択を伴う地点" },
  supply: { label: "補給所", short: "補", description: "補給・整備を行う地点" },
  rest: { label: "休息所", short: "休", description: "休息して立て直す地点" },
  guardian: { label: "終端ボス", short: "終", description: "区間の最後に待つ高難度の地点" },
  custom: { label: "任意", short: "任", description: "自由に設定する地点" },
};
const colors: Record<Accent, string> = { gold: "#d7ad54", ember: "#ef4d52", ash: "#6ed6dc" };
const legacyAccents: Record<string, Accent> = { brass: "gold", teal: "ember", slate: "ash" };
const legacyKinds: Record<string, NodeKind> = { start: "origin", battle: "skirmish", elite: "elite", event: "event", shop: "supply", rest: "rest", boss: "guardian", custom: "custom" };
const legacyDefaultLabels: Partial<Record<NodeKind, string[]>> = {
  origin: ["起点"],
  skirmish: ["通過点", "戦闘", "小規模交戦", "通常遭遇"],
  focused: ["収束点", "正面衝突", "集中遭遇"],
  elite: ["危険点", "精鋭", "危険交戦", "危険遭遇"],
  anomaly: ["変則点", "特異事象", "固有遭遇"],
  event: ["分岐点", "分岐事象", "選択事象"],
  supply: ["補給点", "ショップ", "補給地点"],
  rest: ["休止点", "休息", "休息地点"],
  guardian: ["終端点", "ボス", "終端警戒", "終端遭遇"],
};

const waypointOuterPath = "M -44 -24 L -27 -43 H 27 L 44 -24 V 24 L 27 43 H -27 L -44 24 Z";
const waypointInnerPath = "M -30 -16 L -19 -29 H 19 L 30 -16 V 16 L 19 29 H -19 L -30 16 Z";
const waypointSpokes = ["M -30 -16 L -44 -24", "M 30 -16 L 44 -24", "M 30 16 L 44 24", "M -30 16 L -44 24"];

function resolveKind(value: unknown): NodeKind {
  if (typeof value === "string" && value in kinds) return value as NodeKind;
  return legacyKinds[String(value)] ?? "custom";
}
function clean(value: unknown, max = 28) { return String(value ?? "").replace(/[<>]/g, "").slice(0, max); }
function isDefaultNodeLabel(kind: NodeKind, label: string) { return label === kinds[kind].label || legacyDefaultLabels[kind]?.includes(label) === true; }
function normalizeNodeLabel(value: unknown, kind: NodeKind) { const label = clean(value); return !label || isDefaultNodeLabel(kind, label) ? kinds[kind].label : label; }
function clone<T>(value: T): T { return JSON.parse(JSON.stringify(value)); }
function uuid() { return globalThis.crypto?.randomUUID?.() ?? `node_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`; }
function escapeXml(value: unknown) { return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"); }
export function defaultAccent(kind: NodeKind): Accent {
  if (kind === "elite" || kind === "anomaly" || kind === "guardian") return "ember";
  return "ash";
}
function nodeSeed(stage: number, index = 0): RouteNode {
  const defaults: NodeKind[] = ["origin", "skirmish", "event", "supply", "guardian"];
  const kind = stage === 0 ? "origin" : defaults[Math.min(stage, defaults.length - 1)] ?? "custom";
  return { id: uuid(), stage, kind, icon: "", label: index ? `地点 ${stage + 1}-${index + 1}` : kinds[kind].label, accent: defaultAccent(kind) };
}
function deriveEdges(nodes: RouteNode[]): [string, string][] {
  const highest = Math.max(0, ...nodes.map((node) => node.stage));
  const edges: [string, string][] = [];
  for (let stage = 0; stage < highest; stage += 1) {
    const from = nodes.filter((node) => node.stage === stage);
    const to = nodes.filter((node) => node.stage === stage + 1);
    from.forEach((a) => to.forEach((b) => edges.push([a.id, b.id])));
  }
  return edges;
}
function ensureColumns(nodes: RouteNode[]) {
  const result = [...nodes];
  const highest = Math.max(0, ...result.map((node) => node.stage));
  for (let stage = 0; stage <= highest; stage += 1) if (!result.some((node) => node.stage === stage)) result.push(nodeSeed(stage));
  const origin = result.find((node) => node.stage === 0);
  if (origin) { origin.kind = "origin"; origin.label ||= "起点"; }
  return result.sort((a, b) => a.stage - b.stage || a.id.localeCompare(b.id));
}

export const baseTree = (): RouteTree => {
  const origin = { id: "origin", stage: 0, kind: "origin" as NodeKind, icon: "", label: "起点", accent: "ash" as Accent };
  const nodes: RouteNode[] = [
    origin,
    { id: "skirmish", stage: 1, kind: "skirmish", icon: "", label: "通過点", accent: "ash" },
    { id: "event", stage: 1, kind: "event", icon: "", label: "分岐点", accent: "ash" },
    { id: "rest", stage: 1, kind: "rest", icon: "", label: "休止点", accent: "ash" },
    { id: "focused", stage: 2, kind: "focused", icon: "", label: "収束点", accent: "ash" },
    { id: "elite", stage: 2, kind: "elite", icon: "", label: "危険点", accent: "ember" },
    { id: "anomaly", stage: 2, kind: "anomaly", icon: "", label: "変則点", accent: "ember" },
    { id: "supply", stage: 3, kind: "supply", icon: "", label: "補給点", accent: "ash" },
    { id: "guardian", stage: 4, kind: "guardian", icon: "", label: "終端点", accent: "ember" },
  ];
  return { title: "移動ツリー", nodes, edges: deriveEdges(nodes), theme: { background: STANDARD_THEME.background, line: STANDARD_THEME.line, showLabels: false, iconSize: 27 } };
};

export function normalize(input: unknown): RouteTree {
  const fallback = baseTree();
  if (!input || typeof input !== "object") return fallback;
  const source = input as Partial<RouteTree>;
  const sourceNodes = Array.isArray(source.nodes) ? source.nodes : [];
  const parsed = sourceNodes.filter((node): node is RouteNode => Boolean(node && typeof node === "object" && (node as RouteNode).id)).map((node, index) => ({
    id: clean(node.id, 48) || `node_${index}`,
    stage: Math.max(0, Math.min(MAX_COLUMNS - 1, Number.parseInt(String(node.stage), 10) || 0)),
    kind: resolveKind(node.kind),
    icon: clean(node.icon, 6),
    label: normalizeNodeLabel(node.label, resolveKind(node.kind)),
    accent: node.accent in colors ? node.accent : legacyAccents[String(node.accent)] ?? defaultAccent(resolveKind(node.kind)),
  }));
  const prepared = ensureColumns(parsed.length ? parsed : fallback.nodes);
  return {
    title: clean(source.title, 40) || "移動ツリー",
    nodes: prepared,
    edges: deriveEdges(prepared),
    theme: {
      background: source.theme?.background === LEGACY_STANDARD_THEME.background || source.theme?.background === DANTE_STANDARD_THEME.background ? STANDARD_THEME.background : typeof source.theme?.background === "string" ? source.theme.background : fallback.theme.background,
      line: source.theme?.line === LEGACY_STANDARD_THEME.line || source.theme?.line === DANTE_STANDARD_THEME.line ? STANDARD_THEME.line : typeof source.theme?.line === "string" ? source.theme.line : fallback.theme.line,
      showLabels: Boolean(source.theme?.showLabels),
      iconSize: Math.max(18, Math.min(42, Number(source.theme?.iconSize) || fallback.theme.iconSize)),
    },
  };
}

export function changeNodeKind(node: RouteNode, kind: NodeKind): RouteNode {
  const label = isDefaultNodeLabel(node.kind, node.label) || !node.label.trim() ? kinds[kind].label : node.label;
  return { ...node, kind, label };
}

export type TreeHistory = { past: RouteTree[]; present: RouteTree; future: RouteTree[] };
export function createTreeHistory(tree: RouteTree): TreeHistory { return { past: [], present: normalize(tree), future: [] }; }
export function recordTreeChange(history: TreeHistory, next: RouteTree): TreeHistory {
  const prepared = normalize(next);
  if (JSON.stringify(prepared) === JSON.stringify(history.present)) return history;
  return { past: [...history.past, clone(history.present)].slice(-HISTORY_LIMIT), present: prepared, future: [] };
}
export function undoTreeHistory(history: TreeHistory): TreeHistory {
  if (!history.past.length) return history;
  const prior = history.past[history.past.length - 1];
  return { past: history.past.slice(0, -1), present: clone(prior), future: [clone(history.present), ...history.future].slice(0, HISTORY_LIMIT) };
}
export function redoTreeHistory(history: TreeHistory): TreeHistory {
  if (!history.future.length) return history;
  const next = history.future[0];
  return { past: [...history.past, clone(history.present)].slice(-HISTORY_LIMIT), present: clone(next), future: history.future.slice(1) };
}
function loadTree(): RouteTree {
  try { return normalize(JSON.parse(localStorage.getItem(STORAGE_KEY) ?? localStorage.getItem("orbital-route-atlas.v1") ?? "")); } catch { return baseTree(); }
}
function useTreeHistory() {
  const [history, setHistory] = useState<TreeHistory>(() => createTreeHistory(loadTree()));
  const tree = history.present;
  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(tree)); }, [tree]);
  const mutate = (action: (draft: RouteTree) => void) => setHistory((previous) => { const next = clone(previous.present); action(next); return recordTreeChange(previous, next); });
  const replace = (next: RouteTree) => setHistory((previous) => recordTreeChange(previous, next));
  const undo = () => setHistory((previous) => undoTreeHistory(previous));
  const redo = () => setHistory((previous) => redoTreeHistory(previous));
  return { tree, mutate, replace, undo, redo, canUndo: history.past.length > 0, canRedo: history.future.length > 0 };
}

export function layoutFor(tree: RouteTree) {
  const highestStage = Math.max(0, ...tree.nodes.map((node) => node.stage));
  const columns = Array.from({ length: highestStage + 1 }, (_, stage) => tree.nodes.filter((node) => node.stage === stage));
  const widest = Math.max(1, ...columns.map((column) => column.length));
  const width = Math.max(820, 190 + highestStage * 220);
  const height = Math.max(520, 168 + (widest - 1) * 124);
  const positions: Record<string, { x: number; y: number }> = {};
  columns.forEach((column, stage) => {
    const span = Math.max(0, (column.length - 1) * 124);
    const routeTop = Math.max(112, Math.round((height - span) * .37));
    column.forEach((node, index) => { positions[node.id] = { x: 94 + stage * 220, y: routeTop + index * 124 }; });
  });
  return { width, height, positions, columns };
}

function markerSvg(kind: NodeKind, color: string, icon: string) {
  if (kind === "custom" && icon) return `<text x="0" y="9" text-anchor="middle" fill="${color}" font-family="sans-serif" font-size="25">${escapeXml(icon)}</text>`;
  const source = encounterIconSources[kind === "custom" ? "origin" : kind];
  return `<image href="${escapeXml(source)}" x="-29" y="-29" width="58" height="58" preserveAspectRatio="xMidYMid meet"/>`;
}
function NodeMark({ node, color }: { node: RouteNode; color: string }) {
  if (node.kind === "custom" && node.icon) return <text x="0" y="9" textAnchor="middle" fill={color} fontSize="25">{node.icon}</text>;
  const kind = node.kind === "custom" ? "origin" : node.kind;
  return <image href={encounterIconSources[kind]} x="-29" y="-29" width="58" height="58" preserveAspectRatio="xMidYMid meet" />;
}
function NodeFrame({ color, selected = false }: { color: string; selected?: boolean }) {
  return <><path d={waypointOuterPath} fill="#07171b" stroke={color} strokeWidth={selected ? 4.8 : 3} strokeLinejoin="round" /><path d={waypointInnerPath} fill="none" stroke={color} strokeOpacity=".56" strokeWidth="2" strokeLinejoin="round" />{waypointSpokes.map((d) => <path key={d} d={d} fill="none" stroke={color} strokeOpacity=".56" strokeWidth="2" strokeLinecap="round" />)}</>;
}

export function buildSvg(tree: RouteTree) {
  const { width, height, positions } = layoutFor(tree);
  const paths = tree.edges.map(([from, to]) => {
    const a = positions[from]; const b = positions[to]; if (!a || !b) return "";
    const bend = Math.max(46, (b.x - a.x) * .47);
    const d = `M ${a.x + 48} ${a.y} C ${a.x + bend} ${a.y}, ${b.x - bend} ${b.y}, ${b.x - 48} ${b.y}`;
    return `<path d="${d}" fill="none" stroke="${escapeXml(tree.theme.line)}" stroke-opacity=".18" stroke-width="8" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${escapeXml(tree.theme.line)}" stroke-width="2.6" stroke-linecap="round"/>`;
  }).join("");
  const nodes = tree.nodes.map((node) => {
    const p = positions[node.id]; if (!p) return "";
    const color = colors[node.accent];
    const label = tree.theme.showLabels ? `<text x="${p.x}" y="${p.y + 61}" text-anchor="middle" fill="#eef5f7" font-family="Noto Sans JP, sans-serif" font-size="14">${escapeXml(node.label)}</text>` : "";
    const frame = `<path d="${waypointOuterPath}" fill="#07171b" stroke="${color}" stroke-width="3" stroke-linejoin="round"/><path d="${waypointInnerPath}" fill="none" stroke="${color}" stroke-opacity=".56" stroke-width="2" stroke-linejoin="round"/>${waypointSpokes.map((d) => `<path d="${d}" fill="none" stroke="${color}" stroke-opacity=".56" stroke-width="2" stroke-linecap="round"/>`).join("")}`;
    return `<g transform="translate(${p.x} ${p.y})">${frame}${markerSvg(node.kind, color, node.icon)}${label ? `<g transform="translate(${-p.x} ${-p.y})">${label}</g>` : ""}</g>`;
  }).join("");
  const fieldY = height - 32;
  const field = `<g opacity=".42"><path d="M 36 ${fieldY} H ${width - 36}" fill="none" stroke="${escapeXml(tree.theme.line)}" stroke-width="1" stroke-dasharray="2 7"/><path d="M 36 ${fieldY - 14} V ${fieldY + 14} M ${width - 36} ${fieldY - 14} V ${fieldY + 14}" fill="none" stroke="#d7ad54" stroke-width="1.3"/><text x="48" y="${fieldY - 11}" fill="#d7ad54" font-family="monospace" font-size="10">ROUTE FIELD / ${String(tree.nodes.length).padStart(2, "0")} WAYPOINTS</text></g>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" rx="18" fill="${escapeXml(tree.theme.background)}"/>${field}${paths}${nodes}</svg>`;
}

function downloadText(filename: string, body: string, type: string) {
  const url = URL.createObjectURL(new Blob([body], { type }));
  const link = document.createElement("a"); link.href = url; link.download = filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function RouteCanvas({ tree, selectedId, onNodeClick }: { tree: RouteTree; selectedId: string; onNodeClick: (id: string) => void }) {
  const { width, height, positions, columns } = layoutFor(tree);
  const viewportRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{ id: number; x: number; y: number } | null>(null);
  const movedRef = useRef(false);
  const suppressClickRef = useRef(false);
  const isNarrow = () => window.matchMedia("(max-width: 640px)").matches;
  const fit = () => {
    const viewport = viewportRef.current; if (!viewport) return;
    const next = isNarrow() ? Math.max(.33, Math.min(1, Math.min((viewport.clientWidth - 18) / width, (viewport.clientHeight - 18) / height))) : 1;
    setZoom(next); setPan({ x: 0, y: 0 });
  };
  const focusNode = (id: string) => {
    const viewport = viewportRef.current; const point = positions[id];
    if (!viewport || !point || !isNarrow()) return;
    const nextZoom = Math.max(.72, Math.min(.92, Number(((viewport.clientWidth - 28) / 390).toFixed(2))));
    setZoom(nextZoom);
    setPan({ x: Number(((width / 2 - point.x) * nextZoom).toFixed(1)), y: Number(((height / 2 - point.y) * nextZoom - viewport.clientHeight * .08).toFixed(1)) });
  };
  useEffect(() => {
    const adjust = () => { if (isNarrow()) focusNode(selectedId); else fit(); };
    adjust(); const observer = new ResizeObserver(adjust);
    if (viewportRef.current) observer.observe(viewportRef.current);
    return () => observer.disconnect();
  }, [selectedId, width, height]);
  const changeZoom = (step: number) => setZoom((value) => Math.max(.33, Math.min(2.4, Number((value + step).toFixed(2)))));
  const onPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0 && event.pointerType === "mouse") return;
    dragRef.current = { id: event.pointerId, x: event.clientX, y: event.clientY }; movedRef.current = false; event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current; if (!drag || drag.id !== event.pointerId) return;
    const dx = event.clientX - drag.x; const dy = event.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 3) movedRef.current = true;
    if (movedRef.current) setPan((value) => ({ x: value.x + dx, y: value.y + dy }));
    dragRef.current = { id: event.pointerId, x: event.clientX, y: event.clientY };
  };
  const onPointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (dragRef.current?.id !== event.pointerId) return;
    if (movedRef.current) { suppressClickRef.current = true; window.setTimeout(() => { suppressClickRef.current = false; }, 0); }
    dragRef.current = null; if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };
  return <div className="canvas-scroll" ref={viewportRef} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp} onWheel={(event) => { if (!event.ctrlKey && !event.metaKey) return; event.preventDefault(); changeZoom(event.deltaY > 0 ? -.08 : .08); }}>
    <div className="canvas-transform" style={{ width, height, left: `calc(50% - ${width / 2}px)`, top: `calc(50% - ${height / 2}px)`, transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}><svg className="route-svg" width={width} height={height} viewBox={`0 0 ${width} ${height}`} role="img" aria-label="左から右へ進む移動ツリーのプレビュー">
      <rect width="100%" height="100%" rx="18" fill={tree.theme.background} />
      <g opacity=".42" aria-hidden="true"><path d={`M 36 ${height - 32} H ${width - 36}`} fill="none" stroke={tree.theme.line} strokeWidth="1" strokeDasharray="2 7" /><path d={`M 36 ${height - 46} V ${height - 18} M ${width - 36} ${height - 46} V ${height - 18}`} fill="none" stroke="#d7ad54" strokeWidth="1.3" /><text x="48" y={height - 43} fill="#d7ad54" fontFamily="monospace" fontSize="10">ROUTE FIELD / {String(tree.nodes.length).padStart(2, "0")} WAYPOINTS</text></g>
      {columns.map((_, index) => <line key={index} x1={94 + index * 220} x2={94 + index * 220} y1="38" y2={height - 38} className="stage-guide" />)}
      {tree.edges.map(([from, to]) => { const a = positions[from]; const b = positions[to]; if (!a || !b) return null; const bend = Math.max(46, (b.x - a.x) * .47); const d = `M ${a.x + 48} ${a.y} C ${a.x + bend} ${a.y}, ${b.x - bend} ${b.y}, ${b.x - 48} ${b.y}`; return <g key={`${from}_${to}`}><path d={d} fill="none" stroke={tree.theme.line} strokeOpacity=".18" strokeWidth="8" strokeLinecap="round" /><path d={d} fill="none" stroke={tree.theme.line} strokeWidth="2.6" strokeLinecap="round" /></g>; })}
      {tree.nodes.map((node) => { const p = positions[node.id]; const selected = selectedId === node.id; const mark = selected ? colors.gold : colors[node.accent]; return <g key={node.id} transform={`translate(${p.x} ${p.y})`} className={`route-node ${selected ? "is-selected" : ""}`} role="button" tabIndex={0} aria-label={`${node.label}を選択`} onClick={() => { if (!suppressClickRef.current) onNodeClick(node.id); }} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); onNodeClick(node.id); } }}>
        <NodeFrame color={mark} selected={selected} />
        <NodeMark node={node} color={mark} />
        {tree.theme.showLabels && <text y="61" textAnchor="middle" fill="#eef5f7" fontSize="14">{node.label}</text>}
      </g>; })}
    </svg></div>
    <div className="canvas-nav" aria-label="地図の表示倍率"><span><Move size={14} /> 表示倍率</span><button className="canvas-focus" type="button" onClick={(event) => { event.stopPropagation(); focusNode(selectedId); }} aria-label="選択地点を表示" title="選択地点を表示"><Crosshair size={14} /></button><div><button type="button" onClick={(event) => { event.stopPropagation(); changeZoom(-.1); }} aria-label="縮小"><Minus size={15} /></button><button type="button" onClick={(event) => { event.stopPropagation(); fit(); }} aria-label="全体表示"><Maximize2 size={14} /></button><button type="button" onClick={(event) => { event.stopPropagation(); changeZoom(.1); }} aria-label="拡大"><Plus size={15} /></button></div></div>
  </div>;
}

export default function Home() {
  const { tree, mutate, replace, undo, redo, canUndo, canRedo } = useTreeHistory();
  const [selectedId, setSelectedId] = useState("origin");
  const [notice, setNotice] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const layout = useMemo(() => layoutFor(tree), [tree]);
  const selected = tree.nodes.find((node) => node.id === selectedId) ?? tree.nodes[0];
  const columnCount = layout.columns.length;
  const message = (text: string) => { setNotice(text); window.setTimeout(() => setNotice(""), 2600); };
  useEffect(() => { if (!tree.nodes.some((node) => node.id === selectedId)) setSelectedId(tree.nodes[0]?.id ?? ""); }, [tree.nodes, selectedId]);
  const performUndo = () => { if (!canUndo) { message("これ以上戻せる編集はありません"); return; } undo(); message("編集を1つ戻しました"); };
  const performRedo = () => { if (!canRedo) { message("やり直せる編集はありません"); return; } redo(); message("編集を1つやり直しました"); };
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((!event.ctrlKey && !event.metaKey) || event.altKey) return;
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, textarea, select, [contenteditable='true']")) return;
      const key = event.key.toLowerCase();
      if (key === "z" && event.shiftKey) { event.preventDefault(); performRedo(); }
      else if (key === "z") { event.preventDefault(); performUndo(); }
      else if (key === "y") { event.preventDefault(); performRedo(); }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [canUndo, canRedo]);
  const updateNode = (id: string, patch: Partial<RouteNode>) => mutate((draft) => { const node = draft.nodes.find((item) => item.id === id); if (node) Object.assign(node, patch); });
  const setNodeKind = (node: RouteNode, kind: NodeKind) => {
    if (node.kind === kind) { setSelectedId(node.id); return; }
    updateNode(node.id, changeNodeKind(node, kind));
    setSelectedId(node.id);
    message(`${kinds[kind].label}へ変更しました`);
  };
  const applyStandardPalette = () => mutate((draft) => {
    draft.theme.background = STANDARD_THEME.background;
    draft.theme.line = STANDARD_THEME.line;
    draft.nodes.forEach((node) => { node.accent = defaultAccent(node.kind); });
  });
  const setColumnCount = (count: number) => {
    mutate((draft) => {
      const current = Math.max(...draft.nodes.map((node) => node.stage)) + 1;
      if (count < current) draft.nodes = draft.nodes.filter((node) => node.stage < count);
      for (let stage = current; stage < count; stage += 1) draft.nodes.push(nodeSeed(stage));
    });
    message(count < columnCount ? "終端側の列を整理しました" : "新しい列を追加しました");
  };
  const addNode = (stage: number) => {
    const count = tree.nodes.filter((node) => node.stage === stage).length;
    if (count >= MAX_NODES_PER_COLUMN) { message("1列に置ける地点は3つまでです"); return; }
    const node = nodeSeed(stage, count);
    mutate((draft) => draft.nodes.push(node)); setSelectedId(node.id); message(`列 ${stage + 1} に地点を追加しました`);
  };
  const removeNode = () => {
    if (!selected || selected.stage === 0) { message("起点は削除できません"); return; }
    const count = tree.nodes.filter((node) => node.stage === selected.stage).length;
    if (count <= 1) { message("各列には少なくとも1つの地点を残します"); return; }
    mutate((draft) => { draft.nodes = draft.nodes.filter((node) => node.id !== selected.id); });
    setSelectedId(tree.nodes.find((node) => node.id !== selected.id)?.id ?? "origin"); message("地点を削除しました");
  };
  const reset = () => { if (!confirm("移動ツリーを初期テンプレートへ戻しますか？")) return; replace(baseTree()); setSelectedId("origin"); message("初期テンプレートへ戻しました"); };
  const exportPng = () => {
    const svg = buildSvg(tree); const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" })); const image = new Image();
    image.onload = () => { const { width, height } = layoutFor(tree); const canvas = document.createElement("canvas"); canvas.width = width * 2; canvas.height = height * 2; const context = canvas.getContext("2d"); context?.drawImage(image, 0, 0, canvas.width, canvas.height); URL.revokeObjectURL(url); canvas.toBlob((blob) => { if (!blob) return; const png = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = png; link.download = "orbital-route-atlas.png"; link.click(); setTimeout(() => URL.revokeObjectURL(png), 1000); message("PNGを保存しました"); }, "image/png"); };
    image.src = url;
  };
  const importTree = (event: React.ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { try { const next = normalize(JSON.parse(String(reader.result))); replace(next); setSelectedId(next.nodes[0]?.id ?? ""); message("ツリー設定を読み込みました"); } catch { message("ツリー設定を読み込めませんでした"); } }; reader.readAsText(file); event.target.value = ""; };

  return <main className="min-h-screen app-shell">
    <header className="topline"><div className="brand"><img src={asset.logo} alt="" /><div className="brand-title"><span>ORBITAL ROUTE ATLAS</span><small>TRPG MOVE MAP GENERATOR</small><i>ATLAS PLATE / OR-01</i></div></div><a className="topline-open" href={import.meta.env.BASE_URL} target="_blank" rel="noopener noreferrer"><ExternalLink size={15} /> 別タブで開く</a></header>
    <section className="hero"><div><p className="eyebrow">ROUTE / BRANCH / MERGE</p><h1>起点を選び、列ごとに経路を組む。</h1><p className="hero-copy">列数と地点種別を整えると、経路は左から右へ自動でつながります。接続を個別に操作する必要はありません。</p></div><span className="hero-coordinate">ATLAS PLATE / A-02 · FORWARD ONLY</span></section>

    <section className="command-strip" aria-label="ツリー操作"><div className="command-copy"><p>ROUTE REGISTER / CURRENT FILE</p><b>{tree.title}</b><span>{columnCount} 列 / {tree.nodes.length} 地点 / {tree.edges.length} 接続</span></div><div className="command-actions"><Button onClick={() => addNode(Math.min(columnCount - 1, 1))} className="brass-button"><Plus size={16} /> 地点を追加</Button><Button variant="outline" onClick={() => fileRef.current?.click()}><FileUp size={16} /> 設定を読む</Button><Button variant="outline" onClick={() => { downloadText("orbital-route-atlas.json", JSON.stringify(tree, null, 2), "application/json"); message("ツリー設定を保存しました"); }}><Save size={16} /> 設定を保存</Button><div className="history-actions" role="group" aria-label="編集履歴"><Button variant="outline" onClick={performUndo} disabled={!canUndo} title="編集を戻す（Ctrl/Cmd + Z）"><Undo2 size={16} /> 戻す</Button><Button variant="outline" onClick={performRedo} disabled={!canRedo} title="やり直す（Ctrl/Cmd + Shift + Z / Ctrl/Cmd + Y）"><Redo2 size={16} /> やり直す</Button></div></div></section>

    <section className="workspace">
      <aside className="editor-rail">
        <div className="rail-title"><div><p className="eyebrow">ROUTE SCHEMA</p><h2>列と地点の設定</h2></div><span>自動接続</span></div>
        <section className="schema-box"><div className="box-heading"><ChevronRight size={15} /><b>経路の長さ</b></div><label className="field"><span>始点から何列まで進めるか</span><select value={columnCount} onChange={(event) => setColumnCount(Number(event.target.value))}>{Array.from({ length: MAX_COLUMNS - 1 }, (_, index) => index + 2).map((count) => <option key={count} value={count}>{count} 列</option>)}</select></label><p>隣り合う列の地点はすべて接続されます。</p></section>
        <section className="column-planner" aria-label="列ごとの地点種別">
          <div className="box-heading"><Move size={15} /><b>地点種別</b></div>
          {layout.columns.map((column, stage) => <div className="route-column" key={stage}>
            <div className="column-heading"><span>列 {stage + 1}</span><small>{stage === 0 ? "起点" : `${column.length} 地点`}</small></div>
            {column.map((node) => <div className={`column-node ${selected.id === node.id ? "is-current" : ""}`} key={node.id}>
              <button type="button" onClick={() => setSelectedId(node.id)} aria-label={`${node.label}を編集`}>
                <svg viewBox="-24 -24 48 48" aria-hidden="true"><NodeMark node={node} color={selected.id === node.id ? colors.gold : colors[node.accent]} /></svg>
                <span>{node.label}</span>
              </button>
              {stage === 0 ? <span className="locked-kind"><i>種別</i>開始地点</span> : <label className="node-kind-control">
                <span>地点種別</span>
                <div className="select-shell">
                  <select aria-label={`${node.label}の地点種別`} value={node.kind} onPointerDown={() => setSelectedId(node.id)} onFocus={() => setSelectedId(node.id)} onChange={(event) => setNodeKind(node, event.target.value as NodeKind)}>
                    {Object.entries(kinds).filter(([key]) => key !== "origin").map(([key, item]) => <option key={key} value={key}>{item.short}　{item.label}</option>)}
                  </select>
                  <ChevronDown size={15} aria-hidden="true" />
                </div>
              </label>}
            </div>)}
            {stage > 0 && <button type="button" className="add-column-node" onClick={() => addNode(stage)} disabled={column.length >= MAX_NODES_PER_COLUMN}><Plus size={13} /> この列に地点を追加</button>}
          </div>)}
        </section>
        <section className="selected-node-box">
          <div className="box-heading"><WandSparkles size={15} /><b>選択中の地点</b></div>
          <div className="selected-kind-readout">
            <span aria-hidden="true">{kinds[selected.kind].short}</span>
            <div><small>現在の地点種別</small><strong>{kinds[selected.kind].label}</strong><p>{kinds[selected.kind].description}</p></div>
          </div>
          {selected.stage === 0 ? <div className="selected-kind-fixed">開始地点は経路の起点として固定されています。</div> : <label className="field kind-editor-field">
            <span>地点種別を変更</span>
            <div className="select-shell selected-kind-select">
              <select aria-label={`${selected.label}の地点種別を変更`} value={selected.kind} onChange={(event) => setNodeKind(selected, event.target.value as NodeKind)}>
                {Object.entries(kinds).filter(([key]) => key !== "origin").map(([key, item]) => <option key={key} value={key}>{item.short}　{item.label} — {item.description}</option>)}
              </select>
              <ChevronDown size={18} aria-hidden="true" />
            </div>
          </label>}
          <label className="field"><span>表示名</span><input value={selected.label} maxLength={28} onChange={(event) => updateNode(selected.id, { label: event.target.value })} /></label>
          {selected.kind === "custom" && <label className="field"><span>任意の記号</span><input value={selected.icon} maxLength={6} placeholder="例：◇ / 鍵 / ◆" onChange={(event) => updateNode(selected.id, { icon: event.target.value })} /></label>}
          <label className="field"><span>縁取り</span><select value={selected.accent} onChange={(event) => updateNode(selected.id, { accent: event.target.value as Accent })}>{Object.entries(colors).map(([key]) => <option key={key} value={key}>{key}</option>)}</select></label>
        </section>
        <div className="appearance-box"><div className="box-heading"><WandSparkles size={15} /><b>画像の見た目</b></div><div className="two-fields"><label className="field"><span>背景</span><input type="color" value={tree.theme.background} onChange={(event) => mutate((draft) => { draft.theme.background = event.target.value; })} /></label><label className="field"><span>接続線</span><input type="color" value={tree.theme.line} onChange={(event) => mutate((draft) => { draft.theme.line = event.target.value; })} /></label></div><Button variant="outline" size="sm" className="theme-reset" onClick={() => { applyStandardPalette(); message("青緑の地図標準配色を適用しました"); }}><RotateCcw size={14} /> 地図標準配色を適用</Button><label className="field"><span>アイコンの大きさ</span><input type="range" min="18" max="42" value={tree.theme.iconSize} onChange={(event) => mutate((draft) => { draft.theme.iconSize = Number(event.target.value); })} /></label><label className="check"><input type="checkbox" checked={tree.theme.showLabels} onChange={(event) => mutate((draft) => { draft.theme.showLabels = event.target.checked; })} /> アイコン名を表示する</label></div>
        <Button variant="ghost" className="danger-button" onClick={removeNode}><Trash2 size={16} /> この地点を削除</Button>
      </aside>
      <article className="canvas-panel" style={{ backgroundImage: `linear-gradient(rgba(4,20,24,.88), rgba(3,11,14,.96)), url(${asset.texture})` }}><header className="canvas-head"><div><p className="eyebrow">ORBITAL CANVAS</p><h2>移動ツリー</h2><span>列をまたぐ地点は自動で接続されます。地点を選んで種別を変えます。</span><p className="canvas-plate">FORWARD ROUTE / {columnCount} COLUMNS · {tree.nodes.length} WAYPOINTS</p></div><div className="export-actions"><Button variant="outline" onClick={() => { downloadText("orbital-route-atlas.svg", buildSvg(tree), "image/svg+xml;charset=utf-8"); message("SVGを保存しました"); }}><Download size={16} /> SVG</Button><Button variant="outline" onClick={exportPng}><FileDown size={16} /> PNG</Button></div></header>
        <RouteCanvas tree={tree} selectedId={selected.id} onNodeClick={setSelectedId} />
        <div className="mobile-flow-actions" aria-label="地図の操作"><p><span /> ROUTE OPERATIONS / NEXT STEP</p><div className="mobile-flow-primary"><Button onClick={() => addNode(Math.min(columnCount - 1, 1))} className="brass-button"><Plus size={16} /> 地点を追加</Button></div><details className="mobile-utility"><summary><span>補助計器</span><small>保存・出力・履歴</small></summary><div className="utility-grid"><Button variant="outline" onClick={() => fileRef.current?.click()}><FileUp size={16} /> 読込</Button><Button variant="outline" onClick={() => { downloadText("orbital-route-atlas.json", JSON.stringify(tree, null, 2), "application/json"); message("ツリー設定を保存しました"); }}><Save size={16} /> 保存</Button><Button variant="outline" onClick={() => { downloadText("orbital-route-atlas.svg", buildSvg(tree), "image/svg+xml;charset=utf-8"); message("SVGを保存しました"); }}><Download size={16} /> SVG</Button><Button variant="outline" onClick={exportPng}><FileDown size={16} /> PNG</Button></div><div className="history-actions mobile-history" role="group" aria-label="編集履歴"><Button variant="outline" onClick={performUndo} disabled={!canUndo} title="編集を戻す"><Undo2 size={16} /> 戻す</Button><Button variant="outline" onClick={performRedo} disabled={!canRedo} title="やり直す"><Redo2 size={16} /> やり直す</Button></div></details></div>
        <footer className="canvas-footer"><span>左から右への一方向ルートです。列を増やすと次の経路が生まれます。</span><Button variant="ghost" size="sm" onClick={reset}><RotateCcw size={15} /> 初期形に戻す</Button></footer>
      </article>
    </section>
    <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={importTree} />
    {notice && <div className="toast" role="status">{notice}</div>}
  </main>;
}
